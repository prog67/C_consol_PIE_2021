﻿using System;
using Microsoft.CodeAnalysis.CSharp.Scripting;


namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {   Console.Write("    Введите выражение:  ");
            var expression = Console.ReadLine();
            var result = Parse(expression);
            Console.WriteLine(result);
        }
        static double Parse(string expression)
        {
            return CSharpScript.EvaluateAsync<double>(expression).Result;
        }
    }
}