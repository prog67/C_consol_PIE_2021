﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Net.WebRequestMethods;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();            
        }
        // метод преобразования рисунка в матрицу типа int      
        public static int[,,] BitmapToByteRgbNaive(Bitmap bmp) 
        {                                                       
            int width = bmp.Width,
                height = bmp.Height;
            int[,,] res = new int[width, height, 3]; // матрица (тензор) из 3-х страиц
            for (int x = 0; x < width; ++x)
            {
                for (int y = 0; y < height; ++y)
                {
                    Color color = bmp.GetPixel(x, y);// структура для цвета в виде ARGB, где А - альфа,задает прозрачность
                    res[x, y,0] = color.R;
                    res[x, y,1] = color.G;
                    res[x, y,2] = color.B;
                }
            }
            return res;
        }
        private void button1_Click(object sender, EventArgs e) // кнопка "Загрузить и преобразовать  изображение"
        {
         //https://ru.stackoverflow.com/questions/446338/c-byte-%D0%B2-image
         //https://habr.com/ru/articles/196578/
         //pictureBox1.Image = System.Drawing.Image.FromFile("C:\\Users\\admin\\Desktop\\PR1\\WindowsFormsApp1\\r1.jpg"); ;   
         
            OpenFileDialog openFileDialog = new OpenFileDialog(); //объект диалогового окна открытия файла
            
            openFileDialog.InitialDirectory = "";
            openFileDialog.Filter = "Image Files | *.jpg; *.jpeg; *.png;" ; 
            openFileDialog.FilterIndex = 2;
            openFileDialog.RestoreDirectory = true;
                        
            var filePath = string.Empty;  // Empty - пустая строка
            if (openFileDialog.ShowDialog() == DialogResult.OK)
                filePath = openFileDialog.FileName;  //получить путь к указанному файлу
            else
            {
                MessageBox.Show("Произошла проблема с открытием файла!");
                return;
            }
                        
            Bitmap img = new Bitmap(filePath, true); // считали рисунок в объект img
            Console.WriteLine("Размеры рисунка: " + img.Height + "   " + img.Width); // вывели его размеры в окно вывода
            pictureBox1.Image = img;  // загрузили рисунок на форму в pictureBox1

            int [,,] BB = BitmapToByteRgbNaive(img);// вызвали метод, преобразующий рисунок в тензор BB

            // _____изменяем тензор BB в соответствии с заданием _________
            int k = 20;
            for (int i = k; i < img.Width-k; i++)
            {
                for (int j = 0; j < img.Height; j++)
                {
                    int s = 0;
                    for (int ii=0;ii< k;++ii)                    
                        s = s + BB[i-ii, j, 0];
                    s = s / k;
                    for (int ii = 0; ii < k; ++ii)
                        BB[i-ii, j, 0] = s;                    
                }
            }
            // _____преобразуем тензор BB обратно в рисунок ___________
            Bitmap MImage = new Bitmap(img.Width, img.Height);//создали новый объект-рисунок по размерам img
            for (int i = 0; i < img.Width; i++)
         {
                for (int j = 0; j < img.Height; j++)
                {
                    // для черно-белого рисунка берем одну страницу любого цвета
                    // MImage.SetPixel(i ,j, Color.FromArgb(BB[i,j,0], BB[i, j, 0], BB[i, j, 0]));
                    
                    // для цветного рисунка
                    MImage.SetPixel(i, j, Color.FromArgb(BB[i, j, 0], BB[i, j, 1], BB[i, j, 2]));
                }
         }
                pictureBox2.Image = MImage; // вывод нового рисунка на форму в pictureBox2
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }

}
